# SRWind
Structural Reliability Wind Pressures on Low-Slope Roofs Using Non-Hurricane ERA5 Data. Case Study: Colombia
